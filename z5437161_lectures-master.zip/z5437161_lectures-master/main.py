lit = "From firstanme.surname@unsw.edu.au Tue Oct 06 10:10:15 2020"
domain = lit.split()[1].split('@')[1]

print(domain)



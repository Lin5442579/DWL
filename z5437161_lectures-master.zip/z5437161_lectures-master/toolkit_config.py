import os

PRJDIR = '/Users/elmerhu/PycharmProjects/toolkit'
DATADIR = os.path.join(PRJDIR, 'data')
